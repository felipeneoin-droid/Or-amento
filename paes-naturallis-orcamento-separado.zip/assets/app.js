
// Dados do orçamento
let budgetData = {
  categories: {
    site: {
      name: "Desenvolvimento do Site",
      color: "#2E8B57",
      items: [
        { id: 1, title: "Site Professional", description: "Desenvolvimento completo do site com design responsivo, 5 páginas principais e formulários de contato", price: 5000, duration: 1, phase: 1 },
        { id: 2, title: "Domínio e Hospedagem Premium", description: "Registro do domínio + hospedagem premium por 1 ano com SSL e backups", price: 800, duration: 1, phase: 1 }
      ]
    },
    seo: {
      name: "SEO e Integração",
      color: "#0A66C2",
      items: [
        { id: 3, title: "Otimização SEO Completa", description: "Configuração completa de SEO técnico, on-page e schema markup", price: 2500, duration: 1, phase: 1 },
        { id: 4, title: "Integração com Analytics e WhatsApp", description: "Configuração do Google Analytics, Search Console e WhatsApp Business", price: 1200, duration: 1, phase: 1 }
      ]
    },
    identidade: {
      name: "Identidade Visual",
      color: "#9C27B0",
      items: [
        { id: 5, title: "Identidade Visual Completa", description: "Desenvolvimento da identidade visual: logo, paleta de cores, tipografia e manual da marca", price: 3000, duration: 1, phase: 1 }
      ]
    },
    google_negocio: {
      name: "Google Meu Negócio",
      color: "#4285F4",
      items: [
        { id: 14, title: "Configuração do Google Meu Negócio", description: "Criação e verificação do perfil, otimização completa com fotos, horários, descrição e serviços", price: 800, duration: 1, phase: 1 },
        { id: 15, title: "Gestão Mensal do Google Meu Negócio", description: "Monitoramento de reviews, respostas a comentários, atualização de informações e relatórios", price: 300, duration: 6, phase: 2 }
      ]
    },
    instagram: {
      name: "Instagram",
      color: "#E4405F",
      items: [
        { id: 6, title: "Gestão Completa do Instagram", description: "Gestão estratégica: 16 posts/mês, 20 stories/mês, engajamento e análise", price: 1800, duration: 6, phase: 2 }
      ]
    },
    linkedin: {
      name: "LinkedIn",
      color: "#0A66C2",
      items: [
        { id: 7, title: "Gestão Completa do LinkedIn", description: "Gestão do perfil corporativo: 8 posts/mês, networking estratégico e engajamento", price: 1500, duration: 6, phase: 2 }
      ]
    },
    conteudo: {
      name: "Conteúdo",
      color: "#FF6B35",
      items: [
        { id: 8, title: "Estratégia e Produção de Conteúdo", description: "Plano editorial, produção de conteúdo educativo e materiais para parceiros", price: 1800, duration: 6, phase: 3 },
        { id: 9, title: "Landing Pages e Materiais B2B", description: "Desenvolvimento de 3 landing pages segmentadas e materiais para clientes B2B", price: 3000, duration: 1, phase: 3 }
      ]
    },
    anuncios: {
      name: "Anúncios",
      color: "#FFD700",
      items: [
        { id: 10, title: "Gestão de Campanhas de Anúncios", description: "Gestão de campanhas Meta Ads, LinkedIn Ads e Google Ads", price: 3000, duration: 4, phase: 4 }
      ]
    },
    campanhas: {
      name: "Campanhas B2B",
      color: "#9C27B0",
      items: [
        { id: 11, title: "Funis de Vendas e Email Marketing", description: "Desenvolvimento de funis de vendas e campanhas de email marketing B2B", price: 2000, duration: 6, phase: 4 }
      ]
    },
    gestao: {
      name: "Gestão",
      color: "#6c757d",
      items: [
        { id: 12, title: "Gestão Estratégica da Conta", description: "Supervisão geral da estratégia, análise de resultados e ajustes contínuos", price: 2500, duration: 6, phase: 4 }
      ]
    },
    plataformas: {
      name: "Plataformas",
      color: "#2196F3",
      items: [
        { id: 13, title: "Ferramentas e Assinaturas", description: "Metricool, Canva Pro, Mailchimp e ferramentas SEO", price: 500, duration: 6, phase: 1 }
      ]
    }
  }
};

// Local storage
function saveToLocalStorage() {
  localStorage.setItem('paesNaturallisBudget', JSON.stringify(budgetData));
}
function loadFromLocalStorage() {
  const saved = localStorage.getItem('paesNaturallisBudget');
  if (saved) budgetData = JSON.parse(saved);
}

// Totais
function calculateTotals() {
  let categoryTotals = {};
  let phaseTotals = {1:0,2:0,3:0,4:0};
  let grandTotal = 0;
  for (const key in budgetData.categories) {
    const category = budgetData.categories[key];
    let sum = 0;
    category.items.forEach(item => {
      const total = item.price * item.duration;
      sum += total; grandTotal += total; phaseTotals[item.phase] += total;
    });
    categoryTotals[key] = sum;
  }
  return { categoryTotals, phaseTotals, grandTotal };
}

// Utils
function generateId() {
  return Math.max(0, ...Object.values(budgetData.categories).flatMap(c => c.items).map(i => i.id)) + 1;
}

// Visão Geral page init
function initVisaoGeral() {
  // Total
  const totals = calculateTotals();
  document.getElementById('total-budget').textContent = `R$ ${totals.grandTotal.toLocaleString('pt-BR', {minimumFractionDigits: 2})}`;

  // Etapas cards já estão no HTML estático, sem mudanças dinâmicas aqui

  // Gráfico
  const labels = [];
  const data = [];
  const colors = [];
  for (const key in budgetData.categories) {
    labels.push(budgetData.categories[key].name);
    data.push(totals.categoryTotals[key]);
    colors.push(budgetData.categories[key].color);
  }
  const ctx = document.getElementById('budgetChart').getContext('2d');
  window._budgetChart && window._budgetChart.destroy && window._budgetChart.destroy();
  window._budgetChart = new Chart(ctx, {
    type: 'doughnut',
    data: { labels, datasets: [{ data, backgroundColor: colors, borderWidth: 2, borderColor: '#fff' }] },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { position: 'bottom' },
        title: { display: true, text: 'Distribuição do Orçamento por Categoria' },
        tooltip: { callbacks: { label: (ctx) => {
          const v = ctx.raw; const total = ctx.dataset.data.reduce((a,b)=>a+b,0);
          const pct = ((v/total)*100).toFixed(1);
          return `R$ ${v.toLocaleString('pt-BR',{minimumFractionDigits:2})} (${pct}%)`;
        }}}
      }
    }
  });
}

// Detalhamento page init
function getCategoryDescription(key) {
  const map = {
    site: "Desenvolvimento completo do site",
    seo: "Otimização SEO e integração com ferramentas analíticas",
    identidade: "Identidade visual da marca e templates",
    google_negocio: "Configuração e gestão do Google Meu Negócio",
    instagram: "Gestão estratégica do perfil e conteúdo",
    linkedin: "Presença profissional e networking B2B",
    conteudo: "Estratégia e produção de conteúdo educativo",
    anuncios: "Campanhas pagas para geração de leads",
    campanhas: "Funis de vendas e email marketing B2B",
    gestao: "Gestão estratégica e relatórios de performance",
    plataformas: "Ferramentas e softwares necessários"
  };
  return map[key] || "Serviços diversos";
}

function initDetalhamento() {
  const totals = calculateTotals();
  // Cards por categoria
  const container = document.getElementById('budget-cards-container');
  container.innerHTML = '';
  for (const key in budgetData.categories) {
    const category = budgetData.categories[key];
    let categoryTotal = 0;
    category.items.forEach(item => categoryTotal += item.price * item.duration);
    const card = document.createElement('div');
    card.className = 'budget-card';
    card.innerHTML = `
      <div class="budget-header">
        <div class="budget-title">${category.name}</div>
        <div class="budget-price">R$ ${categoryTotal.toLocaleString('pt-BR',{minimumFractionDigits:2})}</div>
      </div>
      <div class="budget-items">
        ${category.items.map(item => `
          <div class="budget-item" style="display:flex;justify-content:space-between;margin:8px 0;padding-bottom:8px;border-bottom:1px solid #f0f0f0;">
            <div style="flex:1;">
              <div style="font-weight:bold;">${item.title}</div>
              <div style="font-size:0.9rem;color:#666;">${item.description}</div>
              <div style="font-size:0.8rem;color:#999;">Duração: ${item.duration} ${item.duration===1?'mês':'meses'} | Fase: ${item.phase}</div>
            </div>
            <div style="font-weight:bold;margin-left:12px;">R$ ${(item.price*item.duration).toLocaleString('pt-BR',{minimumFractionDigits:2})}</div>
          </div>
        `).join('')}
      </div>
    `;
    container.appendChild(card);
  }

  // Tabela resumo
  const tbody = document.getElementById('budget-summary-table');
  tbody.innerHTML = '';
  for (const key in budgetData.categories) {
    const category = budgetData.categories[key];
    const categoryTotal = totals.categoryTotals[key];
    const pct = ((categoryTotal / totals.grandTotal) * 100).toFixed(1);
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${category.name}</td>
      <td>${getCategoryDescription(key)}</td>
      <td>R$ ${categoryTotal.toLocaleString('pt-BR',{minimumFractionDigits:2})}</td>
      <td>${pct}%</td>
    `;
    tbody.appendChild(tr);
  }

  // Total
  document.getElementById('detailed-total').textContent = `R$ ${totals.grandTotal.toLocaleString('pt-BR',{minimumFractionDigits:2})}`;
}

// Gerenciar page init
let editingItemId = null;

function openModal(mode, categoryKey=null) {
  const modal = document.getElementById('itemModal');
  const title = document.getElementById('modalTitle');
  if (mode === 'add') {
    title.textContent = 'Adicionar Item ao Orçamento';
    editingItemId = null;
    document.getElementById('itemTitle').value = '';
    document.getElementById('itemDescription').value = '';
    document.getElementById('itemPrice').value = '';
    document.getElementById('itemDuration').value = '1';
    document.getElementById('itemPhase').value = '1';
    if (categoryKey) document.getElementById('itemCategory').value = categoryKey;
  }
  modal.style.display = 'flex';
}
function closeModal(){ document.getElementById('itemModal').style.display='none'; editingItemId=null; }
function addItemToCategory(categoryKey){ openModal('add', categoryKey); }

function updateManagementInterface() {
  const container = document.getElementById('management-container');
  container.innerHTML = '';
  for (const key in budgetData.categories) {
    const category = budgetData.categories[key];
    const card = document.createElement('div');
    card.className = 'management-card';
    card.innerHTML = `
      <div class="management-header">
        <div class="management-title">${category.name}</div>
        <div class="management-actions"><button class="btn btn-edit" onclick="addItemToCategory('${key}')">+</button></div>
      </div>
      <div class="management-items">
        ${category.items.map(item => `
          <div class="management-item" style="margin:10px 0;padding:10px;background:#f9f9f9;border-radius:5px;">
            <div style="font-weight:bold;">${item.title}</div>
            <div style="font-size:0.9rem;margin:5px 0;">${item.description}</div>
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <div>
                <span style="font-weight:bold;">R$ ${item.price.toLocaleString('pt-BR',{minimumFractionDigits:2})}</span>
                <span style="font-size:0.8rem;color:#666;"> x ${item.duration} ${item.duration===1?'mês':'meses'} = R$ ${(item.price*item.duration).toLocaleString('pt-BR',{minimumFractionDigits:2})}</span>
                <div style="font-size:0.8rem;color:#666;">Fase: ${item.phase}</div>
              </div>
              <div class="management-actions">
                <button class="btn btn-edit" onclick="editBudgetItem(${item.id})">Editar</button>
                <button class="btn btn-delete" onclick="deleteBudgetItem(${item.id})">Excluir</button>
              </div>
            </div>
          </div>
        `).join('')}
      </div>
    `;
    container.appendChild(card);
  }
}

function saveBudgetItem() {
  const category = document.getElementById('itemCategory').value;
  const title = document.getElementById('itemTitle').value;
  const description = document.getElementById('itemDescription').value;
  const price = parseFloat(document.getElementById('itemPrice').value);
  const duration = parseInt(document.getElementById('itemDuration').value);
  const phase = parseInt(document.getElementById('itemPhase').value);

  if (!title || !description || isNaN(price) || price<=0 || isNaN(duration) || duration<=0) {
    alert('Preencha todos os campos corretamente.');
    return;
  }

  if (editingItemId) {
    for (const key in budgetData.categories) {
      const items = budgetData.categories[key].items;
      const idx = items.findIndex(i => i.id === editingItemId);
      if (idx !== -1) {
        if (key !== category) {
          const it = items.splice(idx, 1)[0];
          it.title = title; it.description = description; it.price = price; it.duration = duration; it.phase = phase;
          budgetData.categories[category].items.push(it);
        } else {
          items[idx].title = title; items[idx].description = description; items[idx].price = price; items[idx].duration = duration; items[idx].phase = phase;
        }
        break;
      }
    }
  } else {
    const newId = generateId();
    budgetData.categories[category].items.push({ id:newId, title, description, price, duration, phase });
  }
  closeModal();
  updateManagementInterface();
  saveToLocalStorage();
}

function editBudgetItem(id) {
  for (const key in budgetData.categories) {
    const items = budgetData.categories[key].items;
    const item = items.find(i => i.id === id);
    if (item) {
      document.getElementById('itemCategory').value = key;
      document.getElementById('itemTitle').value = item.title;
      document.getElementById('itemDescription').value = item.description;
      document.getElementById('itemPrice').value = item.price;
      document.getElementById('itemDuration').value = item.duration;
      document.getElementById('itemPhase').value = item.phase;
      editingItemId = id;
      document.getElementById('modalTitle').textContent = 'Editar Item do Orçamento';
      document.getElementById('itemModal').style.display = 'flex';
      break;
    }
  }
}

function deleteBudgetItem(id) {
  if (!confirm('Tem certeza que deseja excluir este item do orçamento?')) return;
  for (const key in budgetData.categories) {
    const items = budgetData.categories[key].items;
    const idx = items.findIndex(i => i.id === id);
    if (idx !== -1) { items.splice(idx,1); break; }
  }
  updateManagementInterface();
  saveToLocalStorage();
}

function resetBudget() {
  if (!confirm('Restaurar o orçamento para os valores padrão?')) return;
  localStorage.removeItem('paesNaturallisBudget');
  window.location.reload();
}

function exportBudget() {
  alert('Aqui você pode implementar exportação para PDF ou Excel.');
}

// Bootstrap por página
document.addEventListener('DOMContentLoaded', () => {
  loadFromLocalStorage();
  const page = document.body.dataset.page;
  if (page === 'visao') { initVisaoGeral(); }
  if (page === 'detalhamento') { initDetalhamento(); }
  if (page === 'gerenciar') { updateManagementInterface(); }
});
